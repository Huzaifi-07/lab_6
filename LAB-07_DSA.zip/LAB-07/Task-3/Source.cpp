#include "myLL.h"

int main()
{
	myLL obj;
	int choice;

	cout << "1. Insert node at a specific position. " << endl;
	cout << "2. Delete node at a specific position." << endl;
	cout << "3. Search for an element in the list." << endl;
	cout << "4. Count total number of nodes." << endl;
	cout << "5. Display Linked List. " << endl;
	cout << "6. Exit." << endl;

	do {
		cout << "\nEnter Choice: ";
		cin >> choice;

		if (choice == 1) {
			int Value, Position;

			cout << "Enter a value: ";
			cin >> Value;
			cout << "Enter Position: ";
			cin >> Position;

			obj.insertAtPosition(Value, Position);
		}
		else if (choice == 2) {
			int Val;
			cout << "Enter Value: ";
			cin >> Val;
			if (obj.deleteValue(Val)) {
				cout << "\n" << Val << " is Deleted." << endl;
			}
			else {
				cout << "Value not found." << endl;
			}
		}
		else if (choice == 3) {
			int val;
			cout << "Enter Value to search: ";
			cin >> val;
			if (obj.search(val)) {
				cout << "\n" << val << " is Serached." << endl;
			}
			else {
				cout << "Value not found." << endl;
			}
		}
		else if (choice == 4) {
			cout << "Total Nodes: " << obj.nodesCount() << endl;
		}
		else if (choice == 5) {
			obj.display();
		}
	} while (choice != 6);


	return 0;
}