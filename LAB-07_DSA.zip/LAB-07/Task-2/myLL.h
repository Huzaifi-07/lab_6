#include"LL.h"

class myLL : public linkedlist
{
public:
	void insertvalueatend(int);
	void insertvalueatstart(int);
	bool deletvalue(int);
	bool isempty();
	int deletefromhead();
	void display();

};
void myLL:: insertvalueatend(int value)
{
	node* nn = new node;
	nn->data = value;
	nn->next = nullptr;

	if (head == nullptr)
	{
		head = nn;
	}
	else
	{
		node* temp = head;
		while (1)
		{
			if (temp->next == nullptr)
				break;

				temp = temp->next;

		}
		temp->next = nn;
	}
}
void myLL::insertvalueatstart(int value)
{
	node* nn = new node;
	nn->data = value;
	nn->next = nullptr;

	if (head == nullptr) 
	{
		head = nn;
	}

	else 
	{
		nn->next = head;
		head = nn;

	}
}
bool myLL::isempty()
{
	return head == nullptr;
}

int myLL::deletefromhead()
{
	if (isempty())
		return NULL;

	if (head->next == nullptr)
	{
		int returningValue = head->data;
		delete head;
		head = nullptr;
		return returningValue;
	}

	else
	{
		node* temp = head;
		int returningValue = head->data;

		head = head->next;
		delete temp;
		temp = nullptr;

		return returningValue;

	}
}


bool myLL::deletvalue(int value)
{
	if (isempty())
		return false;

	else if (head->next == nullptr)
	{
		if (head->data == value)
		{
			delete head;
			head = nullptr;
			return true;
		}
		else
			return false;
	}

	else if (head->data == value)
	{
		deletefromhead();
		return true;
	}

	else
	{
		node* temp = head;

		while (temp->next != nullptr && temp->next->data != value)
		{
			temp = temp->next;
		}

		if (temp->next == nullptr)
			return false;

		node* t2 = temp->next;
		temp->next = temp->next->next;
		delete t2;
		return true;
	}
}



	


void myLL::display()
{
	if (head == nullptr)
	{
		cout << " The linkedlist is empty " << endl;
	}
	else
	{
		node* temp = head;

		while (1)
		{
			cout << temp->data << endl;
			temp = temp->next;

			if (temp == nullptr)
				break;
		}
	}

}