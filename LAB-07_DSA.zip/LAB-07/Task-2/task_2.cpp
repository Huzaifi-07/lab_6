#include "myLL.h"
int main()
{
	myLL obj;

	obj.insertvalueatend(10);
	obj.insertvalueatend(20);
	obj.insertvalueatend(30);
	obj.insertvalueatstart(5);
	obj.insertvalueatstart(8);
	

	obj.deletvalue(20);

	
	obj.display();
	return 0;

}