#include "node.h"
#include<iostream>
using namespace std;

class linkedlist
{
protected:
	node* head;
public:
	linkedlist();
	virtual bool isempty() = 0;
	virtual void insertvalueatend(string) = 0;
	virtual void insertvalueatstart(string) = 0;
	virtual string deletefromhead() = 0;
};

linkedlist::linkedlist()
{
	head = nullptr;
}



