#include "myLL.h"
int main()
{
	int choice = 0;
	myLL book1,book2;

	do
	{
		cout << "1.Add a new student to the reservation list" << endl;
		cout << "2.Remove a student from the reservation list" << endl;
		cout << "3.Update a student's priority" << endl;
		cout << "4.Display the current reservation list for a specific book" << endl;
		cout << "5.Count how many students are currently in the reservation list" << endl;
		cout << "6.Automatically remove the student at the front of the queue once the book is returned" << endl;
		cout << "7.Exit" << endl;
		cout << "Enter your choice: ";
		cin >> choice;
		if (choice == 1)
		{

		}
		else if (choice == 2)
		{

		}
		else if (choice == 3)
		{
		}
		else if (choice == 4)
		{
		}
		else if (choice == 5)
		{
		}
		else if (choice == 6)
		{
		}
		else
			cout << "Invalid choice, please try again." << endl;

	} while (choice!=7);
	 
}