#include <iostream>
using namespace std;

struct node
{
	node* next;
	string data;
};
