#include <iostream>
#include <string>
using namespace std;

struct node
{
	node* next;
	string data;
};