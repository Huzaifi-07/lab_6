#include "myLL.h"
int main()
{
	string name;
	int choice = 0;
	myLL obj;
	do
	{
		cout << "Hospital Management System" << endl;
		cout << "1.Add a new patient to the end of the queue" << endl;
		cout << "2.Remove a patient from the queue" << endl;
		cout << "3.Display the current list of patients in order" << endl;
		cout << "4.Exit" << endl;
		cout << "Enter choice: ";
		cin >> choice;
		if (choice==1)
		{
			cout << "Enter name of Patient: ";
			cin.ignore();
			getline(cin, name);
			obj.Add_new_patient(name);
		}
		else if (choice == 2)
		{
			cout << "Patient with name: " << obj.Remove_patient() << " is Removed" << endl;
		}
		else if (choice == 3)
		{
			cout << "Displaying Patients List: " << endl;
			obj.display();
		}
	} while (choice!=4);
	


}