#include <iostream>
using namespace std;
struct Node
{
	int data;
	Node* next;
};