#include "myLL.h"

int main()
{
	myLL obj;
	obj.CreateNode(10);
	obj.CreateNode(20);
	obj.CreateNode(30);
	obj.CreateNode(40);
	obj.display();
	return 0;
}